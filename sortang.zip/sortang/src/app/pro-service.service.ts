import { Injectable } from '@angular/core';
import { HttpClient} from '@angular/common/http';
import { Iproduct } from './iproduct';
import { Observable } from 'rxjs';
@Injectable({
  providedIn: 'root'
})
export class ProServiceService 
{
  constructor(private httpService:HttpClient) { }

private productUrl ="./assets/Product.json";

  getAllProductsList(): Observable<Iproduct[]>
  {
    return this.httpService.get<Iproduct[]>(this.productUrl);
  }
 

}
