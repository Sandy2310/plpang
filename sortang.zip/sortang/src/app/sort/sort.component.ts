import { Component, OnInit } from '@angular/core';
import { Iproduct } from '../iproduct';
import { ProServiceService } from '../pro-service.service';
import { Irating } from '../irating';

@Component({
  selector: 'app-sort',
  templateUrl: './sort.component.html',
  styleUrls: ['./sort.component.css']
})
export class SortComponent implements OnInit {

ProductList: Iproduct[];
RatingList : Irating[];

  constructor(private service:ProServiceService) { }

  ngOnInit() {
    this.service.getAllProductsList().subscribe((data)=>this.ProductList=data);
  }

  sortByLowToHigh(){     
    this.ProductList=this.ProductList.sort(function(a,b){
     return a.prodPrice-b.prodPrice;
    })
  }
    sortByHighToLow(){     
      this.ProductList=this.ProductList.sort(function(a,b){
       return b.prodPrice-a.prodPrice;
      })
 }
 sortByViews(){
   this.ProductList=this.ProductList.sort(function(a,b){
     return b.prodViews-a.prodViews;
   })
    }

sortByRating(){
  this.RatingList=this.RatingList.sort(function(a,b)
  {
    return b.prodRate-a.prodRate;
  })
}


}

