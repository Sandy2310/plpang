export class Iproduct 
{
    public prodId:string;
    public prodPrice:number;
    public prodViews:number;
}
