export class Irating 
{
    public prodId:string;
    public prodRate:number;

}
