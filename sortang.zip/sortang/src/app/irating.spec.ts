import { Irating } from './irating';

describe('Irating', () => {
  it('should create an instance', () => {
    expect(new Irating()).toBeTruthy();
  });
});
